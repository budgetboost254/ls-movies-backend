package com.lsmovies.data;

public class MovieItem {
    public String title;
    public String url;
    public String subtitles;
}
