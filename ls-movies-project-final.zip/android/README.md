# LS Movies Android App
Java-based streaming app with Firebase login and ExoPlayer support.