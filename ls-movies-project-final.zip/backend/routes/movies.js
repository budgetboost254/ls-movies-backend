const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    res.json([
        {
            title: 'Inception',
            url: 'https://example.com/inception.mp4',
            subtitles: 'https://example.com/inception.vtt'
        },
        {
            title: 'The Matrix',
            url: 'https://example.com/matrix.mp4',
            subtitles: 'https://example.com/matrix.vtt'
        }
    ]);
});

module.exports = router;
