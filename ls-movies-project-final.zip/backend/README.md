# LS Movies Backend API
Mock API using Node.js and Express.